# CSCI102-Final-Project
# 5 Guys One News Site

"It's gonna be a news site I think" - Cole

"Definetely a news site" - Jon

aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
